from imchrome.imchrome import ImChrome

__version__ = 0.1
init = ImChrome
